function ex_PlotMODELS_sevilmis(pcd_img)

    pcshow(pcd_img);

end