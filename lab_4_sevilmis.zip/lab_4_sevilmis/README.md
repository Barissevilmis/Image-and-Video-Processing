LAB - 4 - BARIS SEVILMIS, RUN INSTRUCTIONS:

Exercise 0:Initialize eveything, last state of the work bench can not be uploaded, as the size is too large. Need to run the whole code again.

Exercise 1: Run anycase: SI & TI calculation for reference content, executes fast.

Exercise 2: Run if you want to have sampled YUV and RGB based processed videos. For later exercises: FR and NR metrics videos_orr required: videos_orr is created in this part

Rest of the exercises: For FR and NR computations need to run Exercise 0 - Exercise 2
     	    	       For MOS need to run Exercise 0 - Exercise 2

For plots: Subjective vs Objective Scores : Need both MOS, FR and NR metrics.

In any case, code is commented: please run exercises in ascending order.

For any remaining issues, please contact: baris.sevilmis@epfl.ch

IMPORTANT NOTE: VIDEO DATAS ARE NOT PROVIDED AS THEY HAVE VERY LARGE SIZE: PLEASE ADD VIDEO FOLDERS: 'mp4', 'mp4_2', 'references'(In case any computations needed)